import React from "react";
import { Container, Row, Col, Card, Form, InputGroup, FormControl, Button, Modal, Offcanvas } from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faEye, faSearch, faUserPlus } from '@fortawesome/free-solid-svg-icons';
import Pagination from 'react-bootstrap/Pagination';
import {
    Link
} from "react-router-dom";
import axios from "axios";
class Posts extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Items: [],
            userItems: [],
            commentItems: [],
            searchData: "",
            searchedItems: [],
            userComments: [],
            show: false,
            showUserdetail: false,
            showview: false,
            name: "",
            username: "",
            email: "",
            street: "",
            suite: "",
            city: "",
            zipcode: "",
            lat: "",
            lng: "",
            userDetails: {
                id: 0,
                name: "",
                username: "",
                email: "",
                address: {
                    street: "",
                    suite: "",
                    city: "",
                    zipcode: "",
                    geo: {
                        lat: "",
                        lng: ""
                    },
                }
            }
        }
    }

    componentDidMount() {
        fetch("https://jsonplaceholder.typicode.com/posts")

            // .then(res => res.json())
            .then(res => res.json())
            .then(
                (res) => {
                    this.setState({
                        Items: [...res],
                        searchedItems: [...res]
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
        axios.get("https://jsonplaceholder.typicode.com/users")
            .then(
                (res) => {
                    this.setState({
                        userItems: [...res.data],
                    });
                    console.log(this.state.userItems)
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
        axios.get("https://jsonplaceholder.typicode.com/comments")
            .then(
                (res) => {
                    this.setState({
                        commentItems: [...res.data],
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
    }
    componentDidUpdate() {
        console.log("componentDidUpdate")
    }
    componentWillUnmount() {
        console.log("componentWillUnmount")
    }
    listCall = () => {

    }
    nameChange = () => {
        console.log("namechange")
    }
    colorClick = () => {
        this.setState({
            color: this.props.clr,
            text: this.props.text
        });

    }
    searchFilter = (e, value) => {
        this.setState({
            searchData: value
        })
        const result = this.state.Items.filter(item => item.name.includes(value));
        this.setState({
            searchedItems: result
        })
        console.log(this.state.searchedItems);
    }
    showUsername(list) {
        this.setState({
            show: true,
            hoverData: list
        })

    }

    handleClose = () => {
        this.setState({
            show: false,
            hoverData: {}
        })
    }
    showUserdetail = (list) => {

        this.props.detailClick(list);
    }

    editUser = (itemValue) => {
        console.log(itemValue)
        this.setState({
            showUserdetail: true,
            // userDetails: { ...itemValue }
            name: itemValue.name,
            username: itemValue.username,
            email: itemValue.email,
            street: itemValue.street,
            suite: itemValue.suite,
            city: itemValue.city,
            zipcode: itemValue.zipcode,
            lat: itemValue.lat,
            lng: itemValue.lng,
        })

    }

    viewComments = (itemValue) => {
        console.log(itemValue)
        this.setState({
            userComments: itemValue,
            showview: true
        })
        console.log(this.state.userComments.length)
    }
    handleClose = () => {
        this.setState({
            userComments: [],
            showview: false
        })
    }
    handleChange = (e) => {
        // if(e.target.name === "street" || e.target.name === "suite" || e.target.name ==="city" || e.target.name === "zipcode" || e.target.name ==="lat" || e.target.name ==="lng"){

        // }

        this.setState({
           [e.target.name]: e.target.value
        })
 
    }
    saveComment=()=>{
        let userUpdate = {};
        let addressUpdate = {};
        let geoUpdate = {};
        if (!Object.keys(geoUpdate).length) {
            Object.assign(geoUpdate, { lat: this.state.lat, lng: this.state.lng });
        }
        if (!Object.keys(addressUpdate).length) {
            Object.assign(addressUpdate, {
                street: this.state.street,
                suite: this.state.suite,
                city: this.state.city,
                zipcode: this.state.zipcode,
                geo: geoUpdate
            });
        }
        if (!Object.keys(userUpdate).length) {
            Object.assign(userUpdate, {
                name: this.state.name,
                username: this.state.username,
                email: this.state.email,
                address:addressUpdate
            });
        }
        console.log(userUpdate)
    }
    render() {
        console.log("render");

        const { Items, searchData, searchedItems } = this.state;
        const listData = searchedItems ? searchedItems : Items;
        const listItem = listData.map((list, index) =>
            index < 15 ?
                <>
                    <tr >
                        <td style={{ textAlign: "left" }}>{list.id}</td>
                        <td style={{ textAlign: "left" }}>
                            <Button variant="link" >{this.state.userItems?.find(item => item.id === list.userId)?.name}</Button></td>
                        <td style={{ textAlign: "left" }}>{list.title}</td>
                        <td style={{ textAlign: "left" }}>{list.body}</td>
                        <td><FontAwesomeIcon style={{ fontSize: "25px" }} icon={faEye} className="" onClick={() => this.viewComments(this.state.commentItems?.filter(item => item.postId === this.state.userItems?.find(item => item.id === list.userId).id))} />
                            <FontAwesomeIcon icon={faEdit} style={{ fontSize: "25px" }} className="" onClick={() => this.editUser(this.state.userItems.find(item => item.id === list.userId))} /></td>
                    </tr></> : ""
        )

        return (
            <>
                <Container className="main-content">
                    {!this.state.showUserdetail ?
                        <>
                            <div className="table-responsive">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th style={{ textAlign: "left" }} scope="col">Id</th>
                                            <th style={{ textAlign: "left" }} scope="col">Author Name</th>
                                            <th style={{ textAlign: "left" }} scope="col"> Title</th>
                                            <th style={{ textAlign: "left" }} scope="col">Body</th>
                                            <th style={{ textAlign: "left" }} scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {listItem}
                                    </tbody>
                                </table>
                            </div>
                        </>
                        :
                        <>
                            <Form>
                                <Row>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forname">
                                            <Form.Label>Name</Form.Label>
                                            <Form.Control name={"name"} type="text" placeholder="Enter Name" value={this.state.name} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forUN">
                                            <Form.Label>User Name</Form.Label>
                                            <Form.Control name={"username"} type="text" placeholder="Enter User name" value={this.state.username} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="foremail">
                                            <Form.Label>Email</Form.Label>
                                            <Form.Control name={"email"} type="text" placeholder="Enter Email" value={this.state.email} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forstreet">
                                            <Form.Label>Street</Form.Label>
                                            <Form.Control name={"street"} type="text" placeholder="Enter Street" value={this.state.street} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forSui">
                                            <Form.Label>Suite</Form.Label>
                                            <Form.Control name={"suite"} type="text" placeholder="Enter User name" value={this.state.suite} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forci">
                                            <Form.Label>City</Form.Label>
                                            <Form.Control name={"city"} type="text" placeholder="Enter User name" value={this.state.city} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forzipcode">
                                            <Form.Label>Zipcode</Form.Label>
                                            <Form.Control name={"zipcode"} type="text" placeholder="Enter Street" value={this.state.zipcode} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forLt">
                                            <Form.Label>Lat</Form.Label>
                                            <Form.Control name={"lat"} type="text" placeholder="Enter Lat" value={this.state.lat} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                    <Col xs={12} md={6}>
                                        <Form.Group className="mb-3" controlId="forci">
                                            <Form.Label>Lng</Form.Label>
                                            <Form.Control name={"lng"} type="text" placeholder="Enter Lng" value={this.state.lng} onChange={(e) => this.handleChange(e)} />
                                        </Form.Group>
                                    </Col>
                                </Row>

                                <Button variant="primary" onClick={this.saveComment}>
                                    Submit
                                </Button>
                            </Form>

                        </>
                    }
                    <Offcanvas show={this.state.showview} onHide={this.handleClose}>
                        <Offcanvas.Header closeButton>
                            <Offcanvas.Title>User Comments</Offcanvas.Title>
                        </Offcanvas.Header>
                        <Offcanvas.Body>
                            <ol>
                                {this.state.userComments.map(item =>
                                    <li>{item.body}</li>)}
                            </ol>
                        </Offcanvas.Body>
                    </Offcanvas>
                </Container>
            </>
        );
    }
}

export default Posts;
