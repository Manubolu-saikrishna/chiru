import React from "react";
import { Container, Row, Col, Card, Form, InputGroup, FormControl, Button, Modal } from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faUserPlus } from '@fortawesome/free-solid-svg-icons';
import {
    Link
} from "react-router-dom";
import axios from "axios";
class Comments extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Items: [],
            searchData: "",
            searchedItems: [],
            show: false,
            hoverData: {}
        }
    }
    componentDidMount() {
        axios.get("https://jsonplaceholder.typicode.com/comments")
            .then(
                (res) => {
                    this.setState({
                        Items: [...res.data],
                        searchedItems: [...res.data]
                    });
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    this.setState({
                        isLoaded: true,
                        error
                    });
                }
            )
    }
    componentDidUpdate() {
        console.log("componentDidUpdate")
    }
    componentWillUnmount() {
        console.log("componentWillUnmount")
    }
    listCall = () => {

    }
    nameChange = () => {
        console.log("namechange")
    }
    colorClick = () => {
        this.setState({
            color: this.props.clr,
            text: this.props.text
        });

    }
    searchFilter = (e, value) => {
        this.setState({
            searchData: value
        })
        const result = this.state.Items.filter(item => item.name.includes(value));
        this.setState({
            searchedItems: result
        })
        console.log(this.state.searchedItems);
    }
    showUsername(list) {
        this.setState({
            show: true,
            hoverData: list
        })

    }

    handleClose = () => {
        this.setState({
            show: false,
            hoverData: {}
        })
    }
    showUserdetail = (list) => {
      
        this.props.detailClick(list);
    }

    render() {
        console.log("render");
     
        const { Items, searchData, searchedItems } = this.state;
        const listData = searchedItems ? searchedItems : Items;
        const listItem = listData.map(list =>
            <tr >
                <td style={{ textAlign: "left" }}>{list.id}</td>
                <td style={{ textAlign: "left" }}>{list.name}</td>
                <td style={{ textAlign: "left" }}>{list.email}</td>
                <td style={{ textAlign: "left" }}>{list.body}</td>
                <td style={{ textAlign: "left" }}>{list.postId}</td>
            </tr>
        )
        return (
            <>
                <Container className="main-content">
                    <div className="table-responsive">
                        <table className="table">
                            <thead>
                                <tr>
                                    <th style={{ textAlign: "left" }} scope="col">Id</th>
                                    <th style={{ textAlign: "left" }} scope="col">Name</th>
                                    <th style={{ textAlign: "left" }} scope="col"> Email</th>
                                    <th style={{ textAlign: "left" }} scope="col">Body</th>
                                    <th style={{ textAlign: "left", whiteSpace:"nowrap" }} scope="col"> Post Id</th>
                                </tr>
                            </thead>
                            <tbody>
                                {listItem}
                            </tbody>
                        </table>
                    </div>
                </Container>
            </>
        );
    }
}
export default Comments;
