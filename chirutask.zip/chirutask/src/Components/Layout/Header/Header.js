import React from "react";
import { Navbar, Nav, Container, Image, Button, Badge } from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {  faUser, faBars } from '@fortawesome/free-solid-svg-icons';
import './Header.scss';
class Header extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      color: "green",
      text: "Header"
    }
    console.log("constuctor");
  }
  componentDidMount() {
    console.log("componentdidmount")
  }
  componentDidUpdate() {
    console.log("componentDidUpdate")
  }
  componentWillUnmount() {
    console.log("componentWillUnmount")
  }

  nameChange = () => {
    console.log("namechange")
  }
  colorClick = () => {
    this.setState({
      color: this.props.clr,
      text: this.props.text
    });

  }

  render() {
    console.log("render");
    return (
      <>
        <Navbar bg="primary" expand="lg" className="main-navbar">
          <Container fluid>
            <Navbar.Toggle aria-controls="navbarScroll" />
            <FontAwesomeIcon icon={faBars} className="menu-icon"/>
            <Navbar.Collapse id="navbarScroll">
              <Nav className="me-auto">
                {/* <Nav.Link href="#home">All Products</Nav.Link>
                                <Nav.Link href="#features">Shop By Goal</Nav.Link>
                                <Nav.Link href="#pricing">Advice</Nav.Link> */}

              </Nav>
              <div className="d-flex">
                <Button variant="outline-secondary"><FontAwesomeIcon icon={faUser} /></Button>
              </div>
            </Navbar.Collapse>
          </Container>
        </Navbar>
  
      </>
    );
  }
}
// function Header(props) {
//   return <h2 style={{color:props.color}}>{props.name}</h2>;
//     }
export default Header;
