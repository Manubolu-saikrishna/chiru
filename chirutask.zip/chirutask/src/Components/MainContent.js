import React from "react";
import {
    BrowserRouter,
    Routes,
    Route
} from "react-router-dom";
import Posts from "./Pages/Posts";
import Comments from "./Pages/Comments";
import { Col, Container, ListGroup, Row } from "react-bootstrap";
class MainContent extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userDetail: {}
        }

    }
    userDetail = (list) => {
        let userdetail = list
        this.setState({
            userDetail: userdetail
        })
        console.log(this.state.userDetail)
    }
    render() {

        return (
            <>
                <Container fluid>
                    <Row>
                            {/* <Col xs={12} md={2} className={'sidemenu'}>
                                <ListGroup>
                                    <ListGroup.Item><a href="/posts">Posts</a></ListGroup.Item>
                                    <ListGroup.Item><a href="/comments">Comments</a></ListGroup.Item>
                                </ListGroup>
                            </Col> */}
                        <Col xs={12} md={12} className={'maincontent'}>
                            <BrowserRouter>
                                <Routes>
                                    <Route path="/" element={<Posts />} />
                                    <Route path="/posts" element={<Posts />} />
                                    <Route path="/comments" element={<Comments />} />
                                </Routes>
                            </BrowserRouter>
                        </Col>
                    </Row>
                </Container>
            </>
        );
    }
}

export default MainContent;
