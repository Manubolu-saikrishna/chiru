import logo from './logo.svg';
// import './App.css';
import Header from './Components/Layout/Header/Header';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.js';
import './css/scss/master.scss';
import '@fortawesome/free-solid-svg-icons';
import '@fortawesome/fontawesome-svg-core';
import '@fortawesome/free-brands-svg-icons';
import '@fortawesome/free-regular-svg-icons';
import MainContent from './Components/MainContent';
function App() {
  return (
    <div className="App">
      <Header />
      <MainContent/>
      {/* <Router>
        <Route exact path="" component={UserList} />
        <Route path="/userlist" component={UserList} />
        <Route path="/adduser" component={AddUser} />
      </Router> */}
    </div>
  );
}

export default App;
